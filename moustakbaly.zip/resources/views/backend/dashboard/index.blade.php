
{{-- Elmarzougui Abdelghafour --}}

@extends('backend.layouts.app')

@section('content')

    @include('backend.dashboard.section-a')
    @include('backend.dashboard.section-b')
    @include('backend.dashboard.section-c')
    @include('backend.dashboard.section-d')
    @include('backend.dashboard.section-e')

@endsection