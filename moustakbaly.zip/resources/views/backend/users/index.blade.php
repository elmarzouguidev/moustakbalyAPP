
{{-- Elmarzougui Abdelghafour --}}

@extends('backend.layouts.app')

@section('content')

    @include('backend.users.section-a')
   

@endsection
